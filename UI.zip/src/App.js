import logo from "./logo.svg";
import "./App.css";

import GoogleAuth from "./components/GoogleAuth";

function App() {
  return (
    <div className="App">
      <GoogleAuth />
    </div>
  );
}

export default App;
